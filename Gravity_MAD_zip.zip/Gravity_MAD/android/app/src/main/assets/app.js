// app.js

document.addEventListener("DOMContentLoaded", () => {
  // Navigation & Screens state
  let currentScreen = "scr-splash";
  let activeStore = null;
  let activeFlow = "preorder"; // preorder or instore
  let cart = [];
  let appliedCoupon = null;

  // Selected item cache for detail view
  let selectedDetailProduct = null;
  let selectedDetailQty = 1;

  // Cache Dom elements
  const screens = document.querySelectorAll(".screen");
  const navItems = document.querySelectorAll(".nav-item");
  const deviceShell = document.getElementById("device-shell");
  const deviceScreen = document.getElementById("device-screen");

  // Timer simulation variables
  let trackingStep = 1;
  let trackingInterval = null;

  // Navigate to screen function
  function navigateTo(screenId) {
    screens.forEach(s => {
      s.classList.remove("active");
    });
    const target = document.getElementById(screenId);
    if (target) {
      target.classList.add("active");
      currentScreen = screenId;
    }
  }

  // Time stamp update
  function updateTime() {
    const timeEl = document.getElementById("status-time");
    if (timeEl) {
      const now = new Date();
      let hrs = now.getHours();
      let mins = now.getMinutes();
      hrs = hrs < 10 ? '0' + hrs : hrs;
      mins = mins < 10 ? '0' + mins : mins;
      timeEl.textContent = `${hrs}:${mins}`;
    }
  }
  setInterval(updateTime, 60000);
  updateTime();

  // Splash Screen progress indicator timer
  let progress = 0;
  const progressEl = document.getElementById("splash-progress");
  const splashInterval = setInterval(() => {
    progress += 25;
    if (progressEl) progressEl.style.width = `${progress}%`;
    if (progress >= 100) {
      clearInterval(splashInterval);
      navigateTo("scr-login");
    }
  }, 400);

  // Initialize Home Stores List
  function initStores() {
    const listEl = document.getElementById("home-stores-list");
    if (!listEl || !window.mockStores) return;
    listEl.innerHTML = "";
    window.mockStores.forEach(store => {
      const card = document.createElement("div");
      card.className = "card-item";
      card.style.cursor = "pointer";
      card.innerHTML = `
        <div style="display: flex; gap: 12px; align-items: center;">
          <img src="${store.image}" alt="${store.name}" style="width: 50px; height: 50px; border-radius: var(--radius-sm); object-fit: cover;">
          <div style="flex:1;">
            <h4 style="font-size: 13px; font-weight: 700; color: var(--text-main);">${store.name}</h4>
            <p style="font-size: 11px; color: var(--text-muted);">${store.location} • ${store.distance}</p>
            <span style="display: inline-block; background: rgba(46, 204, 113, 0.1); color: var(--primary); font-size: 9px; font-weight: 700; padding: 2px 6px; border-radius: 4px; margin-top: 4px;">Queue: ${store.busy}</span>
          </div>
        </div>
      `;
      card.addEventListener("click", () => {
        selectStore(store);
      });
      listEl.appendChild(card);
    });
  }

  function selectStore(store) {
    activeStore = store;
    document.getElementById("dashboard-store-name").textContent = store.name;
    document.getElementById("dashboard-store-img").src = store.image;
    document.getElementById("dashboard-store-status").textContent = `Connected (Aisles: ${store.aisles})`;
    navigateTo("scr-store-dashboard");
  }

  // Initialize Dynamic Catalog
  function initCatalog() {
    const gridEl = document.getElementById("catalog-items-grid");
    const categoriesEl = document.getElementById("catalog-categories");
    if (!gridEl || !window.mockProducts) return;

    // Categories headers
    const categories = ["All", ...new Set(window.mockProducts.map(p => p.category))];
    categoriesEl.innerHTML = "";
    categories.forEach((cat, idx) => {
      const btn = document.createElement("button");
      btn.className = `btn-control ${idx === 0 ? "active" : ""}`;
      btn.style.fontSize = "11px";
      btn.style.padding = "6px 12px";
      btn.textContent = cat;
      btn.addEventListener("click", () => {
        categoriesEl.querySelectorAll("button").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        renderCatalogItems(cat);
      });
      categoriesEl.appendChild(btn);
    });

    renderCatalogItems("All");
  }

  function renderCatalogItems(categoryFilter) {
    const gridEl = document.getElementById("catalog-items-grid");
    gridEl.innerHTML = "";
    const filtered = categoryFilter === "All" 
      ? window.mockProducts 
      : window.mockProducts.filter(p => p.category === categoryFilter);

    filtered.forEach(p => {
      const card = document.createElement("div");
      card.className = "card-item";
      card.style.display = "flex";
      card.style.gap = "12px";
      card.innerHTML = `
        <img src="${p.image}" alt="${p.name}" style="width: 60px; height: 60px; border-radius: var(--radius-sm); object-fit: cover;">
        <div style="flex: 1; display: flex; flex-direction: column; justify-content: space-between;">
          <div>
            <h4 style="font-size: 13px; font-weight: 700; color: var(--text-main); margin-bottom: 2px;">${p.name}</h4>
            <p style="font-size: 11px; color: var(--text-muted);">₹${p.price.toFixed(2)}</p>
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center; margin-top:6px;">
            <span style="font-size: 10px; background: #FFF9E6; color: #FFA800; padding: 2px 6px; border-radius: 4px; font-weight: 700;">★ ${p.rating}</span>
            <button class="primary-btn" style="padding: 4px 10px; font-size: 11px; width: auto;" data-add-id="${p.id}">Add</button>
          </div>
        </div>
      `;
      
      // Navigate to detail on card click (excluding add button)
      card.addEventListener("click", (e) => {
        if (e.target.hasAttribute("data-add-id")) {
          e.stopPropagation();
          addToCart(p.id, 1);
          return;
        }
        viewProductDetail(p);
      });
      gridEl.appendChild(card);
    });
  }

  // View Product Detail Screen
  function viewProductDetail(p) {
    selectedDetailProduct = p;
    selectedDetailQty = 1;
    document.getElementById("detail-product-img").src = p.image;
    document.getElementById("detail-product-name").textContent = p.name;
    document.getElementById("detail-product-category").textContent = p.category;
    document.getElementById("detail-product-price").textContent = `₹${p.price.toFixed(2)}`;
    document.getElementById("detail-product-description").textContent = p.description;
    document.getElementById("detail-product-nutrition").textContent = p.nutrition;
    document.getElementById("detail-qty-val").textContent = "1";
    navigateTo("scr-product-details");
  }

  // Cart operations
  function addToCart(productId, qty) {
    const item = window.mockProducts.find(p => p.id === productId);
    if (!item) return;

    const existing = cart.find(i => i.product.id === productId);
    if (existing) {
      existing.quantity += qty;
    } else {
      cart.push({ product: item, quantity: qty });
    }
    updateCartUI();
  }

  function updateCartUI() {
    const listEl = document.getElementById("cart-items-list");
    if (!listEl) return;
    listEl.innerHTML = "";

    if (cart.length === 0) {
      listEl.innerHTML = `<p style="text-align: center; color: var(--text-muted); font-size: 13px; margin: 20px 0;">Your cart is empty.</p>`;
      updateCartTotals(0);
      return;
    }

    let subtotal = 0;
    cart.forEach(item => {
      subtotal += item.product.price * item.quantity;
      const card = document.createElement("div");
      card.className = "glass-card";
      card.style.display = "flex";
      card.style.gap = "12px";
      card.style.alignItems = "center";
      card.innerHTML = `
        <img src="${item.product.image}" alt="${item.product.name}" style="width: 44px; height: 44px; border-radius: var(--radius-sm); object-fit: cover;">
        <div style="flex: 1;">
          <h4 style="font-size: 12px; font-weight: 700; color: var(--text-main);">${item.product.name}</h4>
          <p style="font-size: 11px; color: var(--primary); font-weight: 600; margin-top: 2px;">₹${(item.product.price * item.quantity).toFixed(2)}</p>
        </div>
        <div style="display: flex; align-items: center; gap: 8px;">
          <button style="width: 22px; height: 22px; border-radius: 4px; border: 1px solid var(--border); background: var(--bg-surface); color: var(--text-main); cursor: pointer;" class="qty-dec" data-id="${item.product.id}">-</button>
          <span style="font-size: 12px; font-weight: 600;">${item.quantity}</span>
          <button style="width: 22px; height: 22px; border-radius: 4px; border: 1px solid var(--border); background: var(--bg-surface); color: var(--text-main); cursor: pointer;" class="qty-inc" data-id="${item.product.id}">+</button>
        </div>
      `;
      listEl.appendChild(card);
    });

    updateCartTotals(subtotal);
  }

  function updateCartTotals(subtotal) {
    const gst = subtotal * 0.18;
    let discount = 0;
    if (appliedCoupon) {
      discount = appliedCoupon.discount;
    }
    const grandTotal = Math.max(0, subtotal + gst - discount);

    document.getElementById("cart-subtotal").textContent = `₹${subtotal.toFixed(2)}`;
    document.getElementById("cart-gst").textContent = `₹${gst.toFixed(2)}`;
    document.getElementById("cart-discount").textContent = `-₹${discount.toFixed(2)}`;
    document.getElementById("cart-total").textContent = `₹${grandTotal.toFixed(2)}`;
    document.getElementById("pay-total-amount").textContent = `₹${grandTotal.toFixed(2)}`;
  }

  // Cart item increase/decrease click handling
  document.getElementById("cart-items-list").addEventListener("click", (e) => {
    if (e.target.classList.contains("qty-dec")) {
      const id = e.target.getAttribute("data-id");
      const idx = cart.findIndex(i => i.product.id === id);
      if (idx !== -1) {
        cart[idx].quantity--;
        if (cart[idx].quantity <= 0) {
          cart.splice(idx, 1);
        }
        updateCartUI();
      }
    }
    if (e.target.classList.contains("qty-inc")) {
      const id = e.target.getAttribute("data-id");
      const idx = cart.findIndex(i => i.product.id === id);
      if (idx !== -1) {
        cart[idx].quantity++;
        updateCartUI();
      }
    }
  });

  // Coupon handling
  document.getElementById("cart-coupon-apply").addEventListener("click", () => {
    const code = document.getElementById("cart-coupon-input").value.trim().toUpperCase();
    const coupon = window.mockCoupons.find(c => c.code === code);
    const statusEl = document.getElementById("cart-coupon-status");
    if (coupon) {
      appliedCoupon = coupon;
      statusEl.style.display = "block";
      statusEl.textContent = `Coupon "${code}" applied: ₹${coupon.discount} off`;
      updateCartUI();
    } else {
      appliedCoupon = null;
      statusEl.style.display = "block";
      statusEl.style.color = "red";
      statusEl.textContent = `Invalid Coupon Code`;
      updateCartUI();
    }
  });

  // Setup Notification list
  function initNotifications() {
    const listEl = document.getElementById("notifications-list");
    if (!listEl || !window.mockNotifications) return;
    listEl.innerHTML = "";
    window.mockNotifications.forEach(n => {
      const card = document.createElement("div");
      card.className = "glass-card";
      card.style.opacity = n.read ? "0.7" : "1";
      card.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: flex-start;">
          <h4 style="font-size: 13px; font-weight: 700; color: var(--text-main);">${n.title}</h4>
          <span style="font-size: 9px; color: var(--text-muted);">${n.time}</span>
        </div>
        <p style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">${n.body}</p>
      `;
      listEl.appendChild(card);
    });
  }

  // Interactive buttons configuration
  document.getElementById("btn-login-phone").addEventListener("click", () => navigateTo("scr-home"));
  document.getElementById("btn-login-guest").addEventListener("click", () => navigateTo("scr-home"));
  document.getElementById("home-scan-box").addEventListener("click", () => {
    activeFlow = "instore";
    navigateTo("scr-qr-scanner");
  });
  document.getElementById("home-preorder-box").addEventListener("click", () => {
    activeFlow = "preorder";
    if (activeStore) {
      navigateTo("scr-catalog");
    } else {
      // Connect to first store default
      selectStore(window.mockStores[0]);
    }
  });

  // Simulator flow configs
  document.getElementById("btn-flow-preorder").addEventListener("click", () => {
    activeFlow = "preorder";
    selectStore(window.mockStores[0]);
    navigateTo("scr-catalog");
  });

  document.getElementById("btn-flow-instore").addEventListener("click", () => {
    activeFlow = "instore";
    selectStore(window.mockStores[0]);
    navigateTo("scr-qr-scanner");
  });

  // Scanner Simulator scan action
  document.getElementById("btn-trigger-scan").addEventListener("click", () => {
    const val = document.getElementById("mock-scan-select").value;
    if (val.startsWith("store_")) {
      const store = window.mockStores.find(s => s.id === val);
      if (store) selectStore(store);
    } else if (val.startsWith("barcode_")) {
      const prodId = val.replace("barcode_", "");
      addToCart(prodId, 1);
      alert(`Scanned item successfully! Added to Smart Cart.`);
      navigateTo("scr-cart");
    }
  });

  document.getElementById("dashboard-btn-scan-item").addEventListener("click", () => {
    navigateTo("scr-qr-scanner");
  });
  document.getElementById("dashboard-btn-browse").addEventListener("click", () => {
    navigateTo("scr-catalog");
  });

  // Detail qty adjust
  document.getElementById("detail-qty-minus").addEventListener("click", () => {
    if (selectedDetailQty > 1) {
      selectedDetailQty--;
      document.getElementById("detail-qty-val").textContent = selectedDetailQty;
    }
  });
  document.getElementById("detail-qty-plus").addEventListener("click", () => {
    selectedDetailQty++;
    document.getElementById("detail-qty-val").textContent = selectedDetailQty;
  });
  document.getElementById("detail-btn-add").addEventListener("click", () => {
    if (selectedDetailProduct) {
      addToCart(selectedDetailProduct.id, selectedDetailQty);
      navigateTo("scr-catalog");
    }
  });
  document.getElementById("detail-btn-back").addEventListener("click", () => navigateTo("scr-catalog"));

  // Bottom Navigation item clicks
  navItems.forEach(item => {
    item.addEventListener("click", () => {
      navItems.forEach(n => n.classList.remove("active"));
      item.classList.add("active");
      const target = item.getAttribute("data-target");
      if (target === "home") navigateTo("scr-home");
      else if (target === "catalog") navigateTo("scr-catalog");
      else if (target === "qr-scanner") navigateTo("scr-qr-scanner");
      else if (target === "cart") navigateTo("scr-cart");
      else if (target === "profile") navigateTo("scr-profile");
    });
  });

  // Checkouts & Payments
  document.getElementById("cart-btn-checkout").addEventListener("click", () => {
    if (cart.length === 0) {
      alert("Please add items to your cart first.");
      return;
    }
    if (activeFlow === "preorder") {
      navigateTo("scr-order-confirm");
    } else {
      navigateTo("scr-payment");
    }
  });

  document.getElementById("confirm-btn-track").addEventListener("click", () => {
    navigateTo("scr-order-tracking");
    startOrderTrackingSim();
  });

  function startOrderTrackingSim() {
    trackingStep = 1;
    const activeLine = document.getElementById("track-line-active");
    
    // reset steps classes
    document.getElementById("track-step-received").classList.add("active");
    document.getElementById("track-step-packing").classList.remove("active");
    document.getElementById("track-step-ready").classList.remove("active");
    document.getElementById("track-btn-proceed-pay").style.display = "none";
    if (activeLine) activeLine.style.height = "33%";

    if (trackingInterval) clearInterval(trackingInterval);
    trackingInterval = setInterval(() => {
      trackingStep++;
      if (trackingStep === 2) {
        document.getElementById("track-step-packing").classList.add("active");
        if (activeLine) activeLine.style.height = "66%";
      } else if (trackingStep === 3) {
        document.getElementById("track-step-ready").classList.add("active");
        if (activeLine) activeLine.style.height = "100%";
        document.getElementById("track-btn-proceed-pay").style.display = "block";
        clearInterval(trackingInterval);
      }
    }, 3000);
  }

  document.getElementById("track-btn-proceed-pay").addEventListener("click", () => {

    navigateTo("scr-payment");
  });

  document.getElementById("pay-btn-confirm").addEventListener("click", () => {
    // Generate static details for receipt
    const totalQty = cart.reduce((acc, item) => acc + item.quantity, 0);
    document.getElementById("receipt-qty-total").textContent = `${totalQty} items`;
    document.getElementById("receipt-mode").textContent = activeFlow === "preorder" ? "Pre-Order Pickup" : "Self-Checkout Exit";
    
    // Clear cart
    cart = [];
    appliedCoupon = null;
    updateCartUI();

    navigateTo("scr-receipt");
  });

  document.getElementById("receipt-btn-feedback").addEventListener("click", () => {
    navigateTo("scr-feedback");
  });

  document.getElementById("feedback-btn-submit").addEventListener("click", () => {
    alert("Feedback submitted successfully! Thank you for using QuickQ.");
    navigateTo("scr-home");
  });

  // Profile triggers
  document.getElementById("profile-history").addEventListener("click", () => {
    navigateTo("scr-notifications");
  });
  document.getElementById("profile-settings").addEventListener("click", () => {
    navigateTo("scr-settings");
  });
  document.getElementById("profile-btn-logout").addEventListener("click", () => {
    navigateTo("scr-login");
  });
  document.getElementById("settings-btn-save").addEventListener("click", () => {
    navigateTo("scr-profile");
  });
  document.getElementById("home-bell").addEventListener("click", () => {
    navigateTo("scr-notifications");
  });

  // IOS / Android style switcher
  document.getElementById("btn-device-ios").addEventListener("click", () => {
    deviceShell.classList.remove("android-style");
    document.getElementById("btn-device-ios").classList.add("active");
    document.getElementById("btn-device-android").classList.remove("active");
  });

  document.getElementById("btn-device-android").addEventListener("click", () => {
    deviceShell.classList.add("android-style");
    document.getElementById("btn-device-android").classList.add("active");
    document.getElementById("btn-device-ios").classList.remove("active");
  });

  // Theme switches
  document.getElementById("btn-theme-light").addEventListener("click", () => {
    deviceScreen.classList.remove("dark-theme");
    document.getElementById("btn-theme-light").classList.add("active");
    document.getElementById("btn-theme-dark").classList.remove("active");
  });

  document.getElementById("btn-theme-dark").addEventListener("click", () => {
    deviceScreen.classList.add("dark-theme");
    document.getElementById("btn-theme-dark").classList.add("active");
    document.getElementById("btn-theme-light").classList.remove("active");
  });

  // Initial runs
  initStores();
  initCatalog();
  initNotifications();
});
