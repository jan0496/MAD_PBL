// mockData.js
const mockStores = [
  {
    id: "store_mega_mart",
    name: "Mega Mart Hypermarket",
    location: "Forum Mall, Ground Floor",
    rating: 4.8,
    distance: "0.2 km",
    busy: "Moderate",
    aisles: 14,
    image: "https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "store_fresh_grocers",
    name: "Fresh Grocers & Co.",
    location: "Sardar Patel Marg",
    rating: 4.6,
    distance: "1.5 km",
    busy: "Low",
    aisles: 6,
    image: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80"
  },
  {
    id: "store_smart_bazaar",
    name: "Smart Bazaar Mall Store",
    location: "Nexus Mall, Level 2",
    rating: 4.5,
    distance: "2.1 km",
    busy: "High Queue",
    aisles: 20,
    image: "https://images.unsplash.com/photo-1604719312566-8912e9227c6a?auto=format&fit=crop&w=600&q=80"
  }
];

const mockProducts = [
  {
    id: "prod_1",
    name: "Organic Whole Milk 1L",
    category: "Dairy & Eggs",
    barcode: "8901234567890",
    price: 68.00,
    rating: 4.9,
    prepTime: "2 min",
    image: "https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=300&q=80",
    description: "Farm-fresh organic pasteurized whole milk high in Calcium and Vitamin D.",
    ingredients: "Fresh cow milk, Vitamin D3.",
    nutrition: "Calories: 150 kcal, Protein: 8g, Fat: 8g, Carbs: 12g",
    veg: true
  },
  {
    id: "prod_2",
    name: "Premium Avocados (Pack of 2)",
    category: "Fruits & Veggies",
    barcode: "8909876543210",
    price: 180.00,
    rating: 4.7,
    prepTime: "3 min",
    image: "https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&w=300&q=80",
    description: "Perfectly ripe buttery Hass avocados imported from premium orchards.",
    ingredients: "100% Hass Avocados.",
    nutrition: "Calories: 320 kcal, Protein: 4g, Fat: 29g, Fiber: 13g",
    veg: true
  },
  {
    id: "prod_3",
    name: "Crunchy Almond Granola 500g",
    category: "Breakfast & Snacks",
    barcode: "8905556667778",
    price: 349.00,
    rating: 4.5,
    prepTime: "1 min",
    image: "https://images.unsplash.com/photo-1517881917430-e70dfb3610aa?auto=format&fit=crop&w=300&q=80",
    description: "Multigrain cluster granola baked with delicious honey and toasted almonds.",
    ingredients: "Rolled oats, Almonds, Honey, Wheat flour, Rice flour.",
    nutrition: "Calories: 210 kcal per serving, Protein: 6g, Sugar: 9g",
    veg: true
  },
  {
    id: "prod_4",
    name: "Dark Chocolate Chip Cookies",
    category: "Breakfast & Snacks",
    barcode: "8908889990001",
    price: 120.00,
    rating: 4.8,
    prepTime: "1 min",
    image: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=300&q=80",
    description: "Fudgey fresh-baked cookies loaded with rich Belgian dark chocolate chunks.",
    ingredients: "Flour, Dark Chocolate, Butter, Sugar, Eggs.",
    nutrition: "Calories: 240 kcal, Protein: 3g, Fat: 12g, Carbs: 30g",
    veg: false
  },
  {
    id: "prod_5",
    name: "Greek Yogurt Strawberry 150g",
    category: "Dairy & Eggs",
    barcode: "8902223334445",
    price: 55.00,
    rating: 4.6,
    prepTime: "1 min",
    image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=300&q=80",
    description: "Thick, creamy Greek style yogurt blended with real sweet strawberries.",
    ingredients: "Strained yogurt, Strawberry fruit prep, Active cultures.",
    nutrition: "Calories: 120 kcal, Protein: 12g, Fat: 0g, Sugar: 10g",
    veg: true
  },
  {
    id: "prod_6",
    name: "Sparkling Apple Juice 330ml",
    category: "Beverages",
    barcode: "8903334445556",
    price: 90.00,
    rating: 4.4,
    prepTime: "2 min",
    image: "https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=300&q=80",
    description: "Crisp sparkling apple juice with 100% natural fruit extracts and light carbonation.",
    ingredients: "Carbonated water, Apple concentrate, Natural flavors.",
    nutrition: "Calories: 140 kcal, Sugar: 33g, Protein: 0g",
    veg: true
  }
];

const mockCoupons = [
  { code: "SKIPTHELINE", discount: 50.00, description: "₹50 off for first self-checkout order" },
  { code: "MEGAMART100", discount: 100.00, description: "₹100 off on purchases above ₹500" },
  { code: "FREESHIP", discount: 20.00, description: "₹20 packing charge waiver" }
];

const mockNotifications = [
  {
    id: "notif_1",
    title: "Welcome to Forum Mall!",
    body: "Enter Mega Mart & scan the Cart QR to checkout directly from your mobile. Skip a 20-min wait!",
    time: "2 mins ago",
    read: false
  },
  {
    id: "notif_2",
    title: "Weekend Super Sale!",
    body: "Up to 30% off on fresh produce when you use in-app checkout at Fresh Grocers & Co.",
    time: "1 hour ago",
    read: true
  },
  {
    id: "notif_3",
    title: "Order Ready!",
    body: "Your pre-order #QQ-9831 from Mega Mart is packed. Collect from Counter 3.",
    time: "Yesterday",
    read: true
  }
];

window.mockStores = mockStores;
window.mockProducts = mockProducts;
window.mockCoupons = mockCoupons;
window.mockNotifications = mockNotifications;
